package com.example.shoppingcart.fragments.shopping

import androidx.fragment.app.Fragment
import com.example.shoppingcart.R

class SearchFragment : Fragment(R.layout.fragment_search) {
}